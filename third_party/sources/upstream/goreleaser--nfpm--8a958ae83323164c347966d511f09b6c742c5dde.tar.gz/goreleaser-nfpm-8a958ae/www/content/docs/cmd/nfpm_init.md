---
title: nfpm init
---

Creates a sample nfpm.yaml configuration file

```
nfpm init [flags]
```

## Options

```
  -f, --config string   path to the to-be-created config file (default "nfpm.yaml")
  -h, --help            help for init
```

## See also

* [nfpm](/docs/cmd/nfpm/)	 - Packages apps on RPM, Deb, APK, Arch Linux, ipk, and MSIX formats based on a YAML configuration file

