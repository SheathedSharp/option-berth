// Copyright (c) 2014 The fileutil Authors. All rights reserved.
// Use of this source code is governed by a BSD-style
// license that can be found in the LICENSE file.

//go:build !arm && !arm64
// +build !arm,!arm64

package fileutil // import "modernc.org/fileutil"

import (
	"io"
	"os"
)

const hasPunchHole = false

// PunchHole deallocates space inside a file in the byte range starting at
// offset and continuing for len bytes. Unimplemented on DragonFlyBSD.
func PunchHole(f *os.File, off, len int64) error {
	return nil
}

// Fadvise predeclares an access pattern for file data.  See also 'man 2
// posix_fadvise'. Unimplemented on DragonFlyBSD.
func Fadvise(f *os.File, off, len int64, advice FadviseAdvice) error {
	return nil
}

// IsEOF reports whether err is an EOF condition.
func IsEOF(err error) bool { return err == io.EOF }
