package cmd

import (
	"context"
	"fmt"
	"strconv"
	"time"

	"github.com/raskrebs/sonar/internal/daemon/rpc"
	"github.com/raskrebs/sonar/internal/display"
	"github.com/raskrebs/sonar/internal/docker"
	"github.com/raskrebs/sonar/internal/ports"
	"github.com/raskrebs/sonar/internal/state"
	"github.com/spf13/cobra"
)

var infoCmd = &cobra.Command{
	Use:               "info <port>",
	Short:             "Show detailed information about a port",
	Args:              cobra.ExactArgs(1),
	ValidArgsFunction: completePort,
	RunE: func(cmd *cobra.Command, args []string) error {
		port, err := strconv.Atoi(args[0])
		if err != nil {
			return fmt.Errorf("invalid port: %s", args[0])
		}

		infoHost, _ := cmd.Flags().GetString("host")
		bindIP, _ := cmd.Flags().GetString("ip")

		var lp *ports.ListeningPort
		if c := routeRemote(cmd.Context(), infoHost); c != nil {
			defer c.Close()
			var res rpc.PortsInspectResult
			err := remoteCall(cmd.Context(), c, infoHost, "ports.inspect", rpc.Selector{
				Port:        &port,
				BindAddress: strPtrOrNil(bindIP),
			}, &res)
			if err != nil {
				return err
			}
			remote := state.ToListening(res.Port)
			lp = &remote
		} else if infoHost != "" {
			all, scanErr := ports.ScanRemote(infoHost)
			if scanErr != nil {
				return scanErr
			}
			matches := ports.FindAllByPort(port, all)
			if len(matches) == 0 {
				return fmt.Errorf("no process found listening on port %d on %s", port, infoHost)
			}
			if bindIP != "" {
				for i := range matches {
					if matches[i].BindAddress == bindIP {
						lp = &matches[i]
						break
					}
				}
				if lp == nil {
					return fmt.Errorf("no process found listening on %s:%d on %s", bindIP, port, infoHost)
				}
			} else if len(matches) == 1 {
				lp = &matches[0]
			} else {
				lp = &matches[0]
			}
			lp.Type = ports.ClassifyPort(lp.Port)
		} else {
			lp, err = inspectPort(cmd.Context(), port, bindIP)
			if err != nil {
				return err
			}
		}

		printField("Port", display.BoldCyan(fmt.Sprintf("%d", lp.Port)))
		printField("URL", display.Underline(lp.URL()))
		printField("Process", lp.Process)
		printField("PID", fmt.Sprintf("%d", lp.PID))
		printField("Type", lp.Type.String())

		if lp.Command != "" {
			printField("Command", lp.Command)
		}
		if lp.User != "" {
			printField("User", lp.User)
		}
		if lp.BindAddress != "" {
			printField("Bind Address", lp.BindAddress)
		}
		if lp.IPVersion != "" {
			printField("IP Version", lp.IPVersion)
		}

		fmt.Println()
		fmt.Println(display.Bold("Stats:"))
		printField("  CPU", fmt.Sprintf("%.1f%%", lp.CPUPercent))
		if lp.MemoryRSS > 0 {
			printField("  Memory", ports.FormatBytes(lp.MemoryRSS))
		}
		if lp.ThreadCount > 0 {
			printField("  Threads", fmt.Sprintf("%d", lp.ThreadCount))
		}
		if lp.Uptime != "" {
			printField("  Uptime", lp.Uptime)
		}
		if lp.State != "" {
			printField("  State", lp.State)
		}
		printField("  Connections", fmt.Sprintf("%d", lp.Connections))

		fmt.Println()
		fmt.Println(display.Bold("Health:"))
		printField("  Status", colorHealthInfo(lp.HealthStatus))
		if lp.HealthCode > 0 {
			printField("  Status Code", fmt.Sprintf("%d", lp.HealthCode))
		}
		if lp.HealthLatency > 0 {
			printField("  Latency", fmt.Sprintf("%dms", lp.HealthLatency.Milliseconds()))
		}

		if lp.Type == ports.PortTypeDocker {
			fmt.Println()
			fmt.Println(display.Bold("Docker:"))
			if lp.DockerContainer != "" {
				printField("  Container", lp.DockerContainer)
			}
			if lp.DockerImage != "" {
				printField("  Image", lp.DockerImage)
			}
			if lp.DockerContainerPort > 0 {
				printField("  Container Port", fmt.Sprintf("%d", lp.DockerContainerPort))
			}
			if lp.DockerComposeService != "" {
				printField("  Compose Service", lp.DockerComposeService)
			}
			if lp.DockerComposeProject != "" {
				printField("  Compose Project", lp.DockerComposeProject)
			}
		}

		return nil
	},
}

// inspectPort resolves one port's detail view. The daemon answers from the
// shared scan and probes only this port's health, which is what the direct path
// below does too.
func inspectPort(ctx context.Context, port int, bindIP string) (*ports.ListeningPort, error) {
	if c := daemonClient(ctx); c != nil {
		defer c.Close()
		var res rpc.PortsInspectResult
		err := c.Call(ctx, "ports.inspect", rpc.Selector{
			Port:        &port,
			BindAddress: strPtrOrNil(bindIP),
		}, &res)
		if err != nil {
			return nil, cliError(err)
		}
		lp := state.ToListening(res.Port)
		return &lp, nil
	}

	lp, err := ports.FindByPort(port, bindIP)
	if err != nil {
		return nil, err
	}
	enriched := []ports.ListeningPort{*lp}
	docker.EnrichPorts(enriched)
	ports.Enrich(enriched)
	ports.EnrichStats(enriched, docker.AllContainerStatsAsEntries())
	ports.EnrichHealth(enriched, 2*time.Second, 0)
	return &enriched[0], nil
}

func colorHealthInfo(status string) string {
	switch status {
	case "healthy":
		return display.Green(status)
	case "unhealthy", "refused", "timeout":
		return display.Red(status)
	case "non-http":
		return display.Yellow(status)
	default:
		return status
	}
}

func printField(label, value string) {
	fmt.Printf("%-16s %s\n", display.Dim(label+":"), value)
}

func init() {
	infoCmd.Flags().String("host", "",
		"Read a registered `host` through the daemon, or query any user@hostname over SSH")
	_ = infoCmd.RegisterFlagCompletionFunc("host",
		func(cmd *cobra.Command, _ []string, _ string) ([]string, cobra.ShellCompDirective) {
			return remoteHostNames(cmd.Context()), cobra.ShellCompDirectiveNoFileComp
		})
	infoCmd.Flags().String("ip", "", "Specify bind address when a port is bound to multiple IPs")
	rootCmd.AddCommand(infoCmd)
}
