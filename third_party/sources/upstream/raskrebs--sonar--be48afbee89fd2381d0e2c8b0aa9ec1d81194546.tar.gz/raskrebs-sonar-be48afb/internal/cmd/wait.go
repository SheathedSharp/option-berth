package cmd

import (
	"context"
	"encoding/json"
	"fmt"
	"net"
	"os"
	"os/signal"
	"strconv"
	"time"

	"github.com/raskrebs/sonar/internal/daemon/client"
	"github.com/raskrebs/sonar/internal/daemon/rpc"
	"github.com/raskrebs/sonar/internal/display"
	"github.com/raskrebs/sonar/internal/ports"
	"github.com/spf13/cobra"
)

var (
	waitTimeoutFlag  time.Duration
	waitIntervalFlag time.Duration
	waitHTTPFlag     string
	waitQuietFlag    bool
)

var waitCmd = &cobra.Command{
	Use:   "wait <port> [port...]",
	Short: "Block until one or more ports are ready",
	Long: `Block until the specified ports are accepting connections.

By default, sonar wait checks for a TCP connection. Use --http to wait
for an HTTP 200-399 response instead (useful for services that accept
TCP connections before they are truly ready). You can specify a custom
path with --http=<path> (e.g. --http=/health).

Exit codes:
  0  all ports are ready
  1  timeout exceeded
  2  interrupted (Ctrl+C)

Examples:
  sonar wait 5432
  sonar wait 5432 --timeout 30s
  sonar wait 5432 --http
  sonar wait 5432 --http=/health
  sonar wait 5432 3000 6379
  sonar wait 5432 --quiet
  sonar wait 5432 --interval 500ms`,
	Args: cobra.MinimumNArgs(1),
	RunE: func(cmd *cobra.Command, args []string) error {
		// Parse port numbers
		portList := make([]int, 0, len(args))
		for _, arg := range args {
			p, err := strconv.Atoi(arg)
			if err != nil || p < 1 || p > 65535 {
				return fmt.Errorf("invalid port: %s", arg)
			}
			portList = append(portList, p)
		}

		// Set up interrupt handling
		sigCh := make(chan os.Signal, 1)
		signal.Notify(sigCh, os.Interrupt)
		defer signal.Stop(sigCh)

		if !waitQuietFlag {
			label := "TCP"
			if waitHTTPFlag != "" {
				label = fmt.Sprintf("HTTP (%s)", waitHTTPFlag)
			}
			fmt.Printf("%s Waiting for %s on port(s) %v (timeout %s)\n",
				display.Dim("⏳"), label, portList, waitTimeoutFlag)
		}

		if c := daemonClient(cmd.Context()); c != nil {
			defer c.Close()
			code, err := waitThroughDaemon(cmd.Context(), c, portList, sigCh)
			if err != nil {
				return err
			}
			if code != 0 {
				os.Exit(code)
			}
			return nil
		}

		deadline := time.After(waitTimeoutFlag)
		ticker := time.NewTicker(waitIntervalFlag)
		defer ticker.Stop()

		// Track which ports are still pending
		pending := make(map[int]bool, len(portList))
		for _, p := range portList {
			pending[p] = true
		}

		// Check immediately, then on each tick
		for {
			for p := range pending {
				if isPortReady(p, waitHTTPFlag) {
					delete(pending, p)
					if !waitQuietFlag {
						fmt.Printf("  %s port %d ready\n", display.Green("✓"), p)
					}
				}
			}

			if len(pending) == 0 {
				if !waitQuietFlag {
					fmt.Printf("%s All ports ready\n", display.Green("✔"))
				}
				return nil
			}

			select {
			case <-sigCh:
				if !waitQuietFlag {
					fmt.Println()
					fmt.Fprintf(os.Stderr, "%s Interrupted\n", display.Red("✗"))
				}
				os.Exit(2)
			case <-deadline:
				remaining := make([]int, 0, len(pending))
				for p := range pending {
					remaining = append(remaining, p)
				}
				if !waitQuietFlag {
					fmt.Fprintf(os.Stderr, "%s Timeout waiting for port(s) %v\n",
						display.Red("✗"), remaining)
				}
				os.Exit(1)
			case <-ticker.C:
				// next iteration
			}
		}
	},
}

// waitThroughDaemon runs the wait as a stream: the daemon does the probing and
// pushes one chunk per port that comes up, so the printed lines and the
// interrupt behaviour are the same as the local loop's. It returns the process
// exit code the command should use — 0 ready, 1 timed out, 2 interrupted — so
// the decision is testable without spawning a process.
func waitThroughDaemon(ctx context.Context, c *client.Client, portList []int, sigCh <-chan os.Signal) (int, error) {
	s, err := c.Stream(ctx, "ports.wait", rpc.PortsWaitParams{
		Ports:      portList,
		HTTP:       strPtrOrNil(waitHTTPFlag),
		TimeoutMs:  int(waitTimeoutFlag / time.Millisecond),
		IntervalMs: int(waitIntervalFlag / time.Millisecond),
	}, nil)
	if err != nil {
		return 0, cliError(err)
	}
	defer s.Close()

	chunks := s.Chunks()
	for {
		select {
		case <-sigCh:
			_ = s.Cancel(ctx)
			if !waitQuietFlag {
				fmt.Println()
				fmt.Fprintf(os.Stderr, "%s Interrupted\n", display.Red("✗"))
			}
			return 2, nil
		case raw, ok := <-chunks:
			if !ok {
				chunks = nil
				continue
			}
			var chunk rpc.PortsWaitChunk
			if err := json.Unmarshal(raw, &chunk); err != nil {
				continue
			}
			if !waitQuietFlag {
				fmt.Printf("  %s port %d ready\n", display.Green("✓"), chunk.Port)
			}
		case end := <-s.End():
			if end.Err != nil {
				return 0, cliError(end.Err)
			}
			var final rpc.PortsWaitEnd
			if err := end.Decode(&final); err != nil {
				return 0, err
			}
			if len(final.TimedOut) > 0 {
				if !waitQuietFlag {
					fmt.Fprintf(os.Stderr, "%s Timeout waiting for port(s) %v\n",
						display.Red("✗"), final.TimedOut)
				}
				return 1, nil
			}
			if !waitQuietFlag {
				fmt.Printf("%s All ports ready\n", display.Green("✔"))
			}
			return 0, nil
		}
	}
}

// isPortReady checks whether a port is ready via TCP or HTTP.
// If httpPath is non-empty, an HTTP check is performed against that path.
func isPortReady(port int, httpPath string) bool {
	if httpPath != "" {
		result := ports.ProbeHealth("localhost", port, httpPath, 2*time.Second)
		return result.Status == "healthy"
	}

	conn, err := net.DialTimeout("tcp", fmt.Sprintf("localhost:%d", port), 2*time.Second)
	if err != nil {
		return false
	}
	conn.Close()
	return true
}

func init() {
	waitCmd.Flags().DurationVar(&waitTimeoutFlag, "timeout", 30*time.Second, "Maximum time to wait (e.g. 30s, 1m)")
	waitCmd.Flags().DurationVarP(&waitIntervalFlag, "interval", "i", 1*time.Second, "Polling interval (e.g. 1s, 500ms)")
	waitCmd.Flags().StringVar(&waitHTTPFlag, "http", "", "Wait for HTTP 200-399 instead of TCP connection (optionally specify path: --http=/health)")
	waitCmd.Flags().Lookup("http").NoOptDefVal = "/"
	waitCmd.Flags().BoolVarP(&waitQuietFlag, "quiet", "q", false, "No output, just exit code (for scripts)")
	rootCmd.AddCommand(waitCmd)
}
