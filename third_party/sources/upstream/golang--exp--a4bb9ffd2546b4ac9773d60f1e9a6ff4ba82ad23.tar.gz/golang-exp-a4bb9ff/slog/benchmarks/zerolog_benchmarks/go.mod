module golang.org/x/exp/slog/benchmarks/zerolog_benchmarks

go 1.24.0

require (
	github.com/rs/zerolog v1.28.0
	golang.org/x/exp v0.0.0-20251002181428-27f1f14c8bb9
)

require (
	github.com/mattn/go-colorable v0.1.12 // indirect
	github.com/mattn/go-isatty v0.0.14 // indirect
	golang.org/x/sys v0.37.0 // indirect
)

replace golang.org/x/exp => ../../..
