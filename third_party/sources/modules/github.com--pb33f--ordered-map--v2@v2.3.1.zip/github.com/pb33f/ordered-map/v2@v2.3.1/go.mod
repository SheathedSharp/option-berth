module github.com/pb33f/ordered-map/v2

go 1.24

require (
	github.com/bahlo/generic-list-go v0.2.0
	github.com/buger/jsonparser v1.1.2
	github.com/stretchr/testify v1.11.1
	go.yaml.in/yaml/v4 v4.0.0-rc.2
)

require (
	github.com/davecgh/go-spew v1.1.1 // indirect
	github.com/pmezard/go-difflib v1.0.0 // indirect
	gopkg.in/yaml.v3 v3.0.1 // indirect
)
